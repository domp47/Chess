Hi, there!

The documentation of **TensorFlow Debugger (tfdbg)** has moved.

See the source version at
[this new location](../../../docs_src/guide/debugger.md).

See the public website version at
[https://www.tensorflow.org/guide/debugger](https://www.tensorflow.org/guide/debugger).
